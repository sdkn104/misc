[Reflection.Assembly]::LoadFile("C:\Users\sdkn1\Desktop\ClosedXML\run\ClosedXML.dll") 
[Reflection.Assembly]::LoadFile("C:\Users\sdkn1\Desktop\ClosedXML\run\DocumentFormat.OpenXml.dll") 
[System.AppDomain]::CurrentDomain.GetAssemblies() | % { $_.GetName().Name }
$wb = New-Object ClosedXML.Excel.XLWorkbook("C:\Users\sdkn1\Desktop\ClosedXML\run\test.xlsx"); 
$ws =$wb.Worksheet(1); 
for($i=1; $i-lt 20; $i++){ $ws.cell(11,$i).Value = 100+$i; }
for($i=1; $i-lt 20; $i++){ $ws.cell($i,11).Value = 1000+$i; } 
$wb.SaveAs("C:\Users\sdkn1\Desktop\ClosedXML\run\test.xlsx"); 
