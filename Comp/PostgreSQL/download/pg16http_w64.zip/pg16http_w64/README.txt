This is for PostgreSQL 64-bit EDB Windows 64-bit distributions

For EDB: Copy binaries to respective folders in your PostgreSQL  install.

In your database run:


CREATE EXTENSION http;

Compiled with CURL 8.0.1
PCRE 8.33
OPENSSL 3.0.7 (not shipped because EDB provides one)

pgsql-http v1.6.0
https://github.com/pramsey/pgsql-http/releases/tag/v1.6.0

Compiled using mingw64-w64 GCC 8.1 chain (x86_64-win32-seh-rev1, Built by MinGW-W64 project )



To Use, install the extension in your db:
CREATE EXTENSION http;


# quick test

SELECT * FROM http_get('http://postgis.net');

# ssl test
SELECT * FROM http_get('https://postgis.net');

if you get an error - ERROR:  SSL certificate problem: unable to get local issuer certificate, 
then you'll need to specify path to bundle as follows:
You can store the crt file anywhere you like that the postgres daemon has access to.

SELECT http_set_curlopt('CURLOPT_CAINFO', 'C:/Program Files/PostgreSQL/16/ssl/certs/curl-bundle.crt');
SELECT * FROM http_get('https://postgis.net');



