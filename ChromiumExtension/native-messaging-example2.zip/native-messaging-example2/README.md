
native host is NodeJS app.

tested on Windows 10, nodeJS 12.16.3

node.exe was download from Windows Binary (.zip) on https://nodejs.org/en/download/



